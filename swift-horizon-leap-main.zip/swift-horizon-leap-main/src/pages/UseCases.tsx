
import { Shield, AlertTriangle, Clock, Banknote, ArrowUpDown, PieChart } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const UseCases = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-netlink-700 text-white">
          <div className="container px-4 py-16 mx-auto text-center md:py-24 md:px-6">
            <h1 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">Use Cases & Limitations</h1>
            <p className="max-w-2xl mx-auto text-lg text-netlink-100">
              Understanding how Netlink Integration Platform can be implemented and its current boundaries.
            </p>
          </div>
        </section>

        {/* Use Cases Section */}
        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto md:px-6">
            <div className="max-w-3xl mx-auto mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold">Strategic Use Cases</h2>
              <p className="text-lg text-gray-600">
                Netlink Integration Platform addresses critical integration needs for financial institutions.
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {/* Use Case 1 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <ArrowUpDown className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Payment Hub Integration</h3>
                <p className="text-gray-600">
                  Integrate your payment systems with Swift networks for seamless cross-border transfers 
                  and domestic processing with complete message validation and transformation.
                </p>
              </div>

              {/* Use Case 2 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Shield className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Compliance Filtering</h3>
                <p className="text-gray-600">
                  Implement automated sanctions screening and AML/KYC verification within your Swift message 
                  flow, with configurable rule sets and auditable decision trails.
                </p>
              </div>

              {/* Use Case 3 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Clock className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Real-time Reporting</h3>
                <p className="text-gray-600">
                  Generate instant visibility into message traffic with customizable dashboards and 
                  reports, supporting regulatory reporting requirements and operational monitoring.
                </p>
              </div>

              {/* Use Case 4 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <PieChart className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Business Intelligence</h3>
                <p className="text-gray-600">
                  Extract valuable insights from Swift message flows with analytics capabilities, 
                  identifying patterns, anomalies, and business opportunities.
                </p>
              </div>

              {/* Use Case 5 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Banknote className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Treasury Management</h3>
                <p className="text-gray-600">
                  Connect treasury systems directly to Swift networks for liquidity management, FX operations, 
                  and securities transactions with full message validation.
                </p>
              </div>

              {/* Use Case 6 */}
              <div className="p-6 bg-gray-50 border rounded-lg">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-orange-100 rounded-lg text-orange-700">
                  <Clock className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Legacy System Replacement</h3>
                <p className="text-gray-600">
                  Direct replacement for IPLA/SIL/Rosetta with automated migration tools and side-by-side 
                  operation capability to ensure smooth transition before 2026 deadline.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Limitations Section */}
        <section className="py-16 bg-gray-50">
          <div className="container px-4 mx-auto md:px-6">
            <div className="max-w-3xl mx-auto mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold">Current Limitations</h2>
              <p className="text-lg text-gray-600">
                Understanding the current boundaries of the Netlink Integration Platform.
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto divide-y">
              {/* Limitation 1 */}
              <div className="py-6">
                <div className="flex items-start">
                  <div className="mr-4 text-yellow-500">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="mb-2 text-xl font-medium">Cloud Deployment Restrictions</h3>
                    <p className="text-gray-600">
                      Currently, certain high-security deployments may require on-premises installation 
                      due to data sovereignty requirements. Hybrid cloud options will be available in Q4 2025.
                    </p>
                  </div>
                </div>
              </div>

              {/* Limitation 2 */}
              <div className="py-6">
                <div className="flex items-start">
                  <div className="mr-4 text-yellow-500">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="mb-2 text-xl font-medium">Proprietary Protocol Support</h3>
                    <p className="text-gray-600">
                      While all standard Swift formats are supported, integration with certain proprietary 
                      banking protocols may require custom connectors. Our professional services team can assist 
                      with these implementations.
                    </p>
                  </div>
                </div>
              </div>

              {/* Limitation 3 */}
              <div className="py-6">
                <div className="flex items-start">
                  <div className="mr-4 text-yellow-500">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="mb-2 text-xl font-medium">Legacy Code Translation</h3>
                    <p className="text-gray-600">
                      While our migration tools cover most common IPLA customizations, highly specialized 
                      or extensively modified legacy implementations may require additional manual conversion 
                      effort. Our expert services team can provide this assistance.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default UseCases;
