
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Phone, MessageSquare, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Input } from "@/components/ui/input";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().min(6, {
    message: "Please enter a valid phone number.",
  }).optional(),
  company: z.string().min(2, {
    message: "Company name must be at least 2 characters.",
  }),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters.",
  }),
  type: z.enum(["contact", "demo"]),
});

type FormValues = z.infer<typeof formSchema>;

const Contact = () => {
  const location = useLocation();
  const [isRequestType, setIsRequestType] = useState("contact");
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      company: "",
      message: "",
      type: "contact",
    },
  });

  // Extract query parameter if present
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const type = searchParams.get("type");
    if (type === "demo") {
      setIsRequestType("demo");
      form.setValue("type", "demo");
    }
  }, [location, form]);

  const onSubmit = async (data: FormValues) => {
    // Simulate email sending
    try {
      console.log("Form submitted:", data);
      
      // In a real application, here you would send the form data to your email service
      // For now we'll simulate success after a short delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      toast.success("Your message has been sent! We'll get back to you shortly.");
      form.reset();
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error("There was a problem sending your message. Please try again.");
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1">
        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto md:px-6">
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="text-center">
                <h1 className="mb-4 text-3xl font-bold md:text-4xl text-netlink-700">
                  {isRequestType === "demo" ? "Request a Demo" : "Contact Us"}
                </h1>
                <p className="mb-8 text-lg text-gray-600">
                  {isRequestType === "demo" 
                    ? "See how Netlink Integration Platform can transform your Swift integration capabilities."
                    : "Have questions or need assistance? Our team is here to help."
                  }
                </p>
              </div>
              
              <div className="p-8 bg-white border rounded-lg shadow-sm">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <input type="hidden" {...form.register("type")} />
                    
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center">
                              <User className="w-4 h-4 mr-2" /> Name
                            </FormLabel>
                            <FormControl>
                              <Input placeholder="Your name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center">
                              <Mail className="w-4 h-4 mr-2" /> Email
                            </FormLabel>
                            <FormControl>
                              <Input placeholder="your.email@company.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center">
                              <Phone className="w-4 h-4 mr-2" /> Phone (Optional)
                            </FormLabel>
                            <FormControl>
                              <Input placeholder="Your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company</FormLabel>
                            <FormControl>
                              <Input placeholder="Your company name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center">
                            <MessageSquare className="w-4 h-4 mr-2" /> Message
                          </FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder={isRequestType === "demo" 
                                ? "Tell us about your specific requirements for the demo..."
                                : "How can we help you?"}
                              className="min-h-[150px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            {isRequestType === "demo"
                              ? "Include details about your organization's integration needs for a tailored demo."
                              : "Your message will be sent securely to our support team."}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-center">
                      <Button 
                        type="submit"
                        size="lg"
                        className="px-10 bg-netlink-600 hover:bg-netlink-700 text-white"
                      >
                        {isRequestType === "demo" ? "Request Demo" : "Send Message"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
              
              <div className="p-6 bg-gray-50 border rounded-lg">
                <h3 className="mb-4 text-xl font-semibold text-netlink-600">Contact Information</h3>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                  <div className="flex items-start space-x-3">
                    <Mail className="w-5 h-5 text-netlink-600" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm text-gray-600">info@netlink-integration.com</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Phone className="w-5 h-5 text-netlink-600" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm text-gray-600">+1 (555) 123-4567</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <MessageSquare className="w-5 h-5 text-netlink-600" />
                    <div>
                      <p className="font-medium">Support</p>
                      <p className="text-sm text-gray-600">support@netlink-integration.com</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Contact;
