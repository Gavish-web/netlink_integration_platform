
import { Link } from "react-router-dom";
import { ArrowRight, Shield, RefreshCw, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-r from-netlink-700 to-netlink-900 text-white">
          <div className="container px-4 py-16 mx-auto md:py-24 md:px-6">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
              <div className="flex flex-col justify-center space-y-6">
                <div>
                  <span className="inline-block px-3 py-1 mb-4 text-xs font-semibold text-netlink-900 bg-netlink-100 rounded-full">
                    Critical Update
                  </span>
                  <h1 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">
                    Swift Integration Solutions for the Post-IPLA Era
                  </h1>
                  <p className="text-lg text-netlink-100">
                    Prepare for IPLA/SIL end of life in 06/2026 with a seamless transition to the Netlink Integration Platform.
                  </p>
                </div>
                <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
                  <Link to="/key-features">
                    <Button size="lg" className="bg-white text-netlink-700 hover:bg-netlink-50">
                      Explore Key Features <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                  <Link to="/contact?type=demo">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                      Request Demo
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:flex md:items-center md:justify-center">
                <div className="relative">
                  {/* Abstract representation of integration platform */}
                  <div className="absolute w-72 h-72 bg-netlink-500/30 rounded-full animate-pulse" />
                  <div className="relative z-10 p-6 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white/20 rounded-lg">
                        <Layers className="w-8 h-8 mb-2" />
                        <p className="text-sm font-medium">Swift Integration</p>
                      </div>
                      <div className="p-4 bg-white/20 rounded-lg">
                        <RefreshCw className="w-8 h-8 mb-2" />
                        <p className="text-sm font-medium">Real-time Processing</p>
                      </div>
                      <div className="p-4 bg-white/20 rounded-lg">
                        <Shield className="w-8 h-8 mb-2" />
                        <p className="text-sm font-medium">Enhanced Security</p>
                      </div>
                      <div className="p-4 bg-white/20 rounded-lg">
                        <ArrowRight className="w-8 h-8 mb-2" />
                        <p className="text-sm font-medium">Future-Proof</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent" />
        </section>

        {/* End of Life Information */}
        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto md:px-6">
            <div className="max-w-3xl mx-auto">
              <div className="p-6 mb-8 border border-red-200 rounded-lg bg-red-50">
                <h2 className="mb-4 text-2xl font-bold text-red-700">Critical Timeline: IPLA/SIL End of Life 06/2026</h2>
                <p className="text-gray-700">
                  Netlink Integration Platform (NIP) provides a comprehensive solution to replace the functionality 
                  required as a result of Swift PLA/SIL/Rosetta end of life in June 2026. 
                  Begin your migration planning now to ensure seamless business continuity.
                </p>
              </div>
              
              <div className="space-y-8">
                <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="mb-2 text-lg font-semibold">IPLA</h3>
                      <p className="text-gray-600">
                        Integration environment for custom requirements in Swift Alliance Access, providing tailored solutions for complex financial workflows.
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="mb-2 text-lg font-semibold">SIL (Swift Integration Layer)</h3>
                      <p className="text-gray-600">
                        Provides secure integration between customer applications and Alliance Lite 2 / Alliance Cloud, enabling streamlined connectivity.
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="mb-2 text-lg font-semibold">Rosetta</h3>
                      <p className="text-gray-600">
                        The module that allows access to Swift Translation libraries within Swift Alliance Access, ensuring message compatibility.
                      </p>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <h3 className="mb-4 text-xl font-bold">Netlink Integration Platform: Your Migration Solution</h3>
                  <p className="mb-4 text-gray-700">
                    NIP is engineered to be a direct replacement for IPLA, SIL and Rosetta functionality, 
                    providing enhanced features and future-proof architecture to support your Swift integration needs 
                    beyond the 2026 end-of-life deadline.
                  </p>
                  <Link to="/key-features">
                    <Button className="bg-netlink-600 hover:bg-netlink-700 text-white">
                      View Key Features <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
