
import { CheckCircle, Zap, Globe, Lock, Database, Code } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const KeyFeatures = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-netlink-700 text-white">
          <div className="container px-4 py-16 mx-auto text-center md:py-24 md:px-6">
            <h1 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">Key Features</h1>
            <p className="max-w-2xl mx-auto text-lg text-netlink-100">
              Netlink Integration Platform delivers comprehensive capabilities to replace and enhance Swift PLA/SIL/Rosetta functionality.
            </p>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto md:px-6">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {/* Feature 1 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">High Performance</h3>
                <p className="text-gray-600">
                  Optimized message processing delivers up to 10x throughput compared to legacy systems, 
                  with multi-threading and advanced queue management.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Multi-threaded message processing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Asynchronous operation handling</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Load balancing for peak traffic</span>
                  </li>
                </ul>
              </div>

              {/* Feature 2 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Globe className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Comprehensive Connectivity</h3>
                <p className="text-gray-600">
                  Connect to any Swift environment with built-in adapters for Alliance Access, 
                  Alliance Lite2, and Alliance Cloud, with standardized APIs.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Direct Alliance Access integration</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Alliance Lite2 & Cloud compatibility</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">REST/SOAP API support</span>
                  </li>
                </ul>
              </div>

              {/* Feature 3 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Enhanced Security</h3>
                <p className="text-gray-600">
                  Bank-grade security with end-to-end encryption, detailed audit logging, and 
                  role-based access controls exceeding Swift compliance requirements.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">TLS 1.3 & AES-256 encryption</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Granular role-based access</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Comprehensive audit trails</span>
                  </li>
                </ul>
              </div>

              {/* Feature 4 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Database className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Message Translation</h3>
                <p className="text-gray-600">
                  Full replacement for Rosetta with advanced message translation capabilities, 
                  supporting all Swift MT and ISO 20022 MX formats with format validation.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Complete MT/MX format support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Custom format mapping</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Real-time validation rules</span>
                  </li>
                </ul>
              </div>

              {/* Feature 5 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Code className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Extensible Architecture</h3>
                <p className="text-gray-600">
                  Open architecture with plugin system allows for customized business rules and 
                  integration with existing systems through standard interfaces.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Custom plugin development</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Event-driven workflows</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">SDK for extension development</span>
                  </li>
                </ul>
              </div>

              {/* Feature 6 */}
              <div className="p-6 border rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-netlink-100 rounded-lg text-netlink-700">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-bold">Migration Tools</h3>
                <p className="text-gray-600">
                  Purpose-built migration utilities to analyze existing IPLA/SIL implementations and 
                  automate conversion to NIP with minimal disruption.
                </p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Legacy code analysis</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Automated conversion tools</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600 shrink-0" />
                    <span className="text-gray-700">Side-by-side operation</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default KeyFeatures;
