
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="container px-4 py-12 mx-auto md:px-6">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <Link to="/" className="flex items-center">
              <span className="text-xl font-bold text-netlink-600">Netlink</span>
              <span className="ml-1 text-xl font-medium">Integration Platform</span>
            </Link>
            <p className="text-sm text-gray-600">
              Swift integration solutions designed for the future of financial services.
            </p>
          </div>
          
          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900 uppercase">Navigation</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-600 hover:text-netlink-600">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/key-features" className="text-gray-600 hover:text-netlink-600">
                  Key Features
                </Link>
              </li>
              <li>
                <Link to="/use-cases" className="text-gray-600 hover:text-netlink-600">
                  Use Cases & Limitations
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900 uppercase">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-600 hover:text-netlink-600">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-netlink-600">
                  API Reference
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-netlink-600">
                  Support Center
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900 uppercase">Contact</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-600">
                info@netlink-integration.com
              </li>
              <li className="text-gray-600">
                +1 (555) 123-4567
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 mt-8 border-t border-gray-200">
          <p className="text-sm text-center text-gray-500">
            © {new Date().getFullYear()} Netlink Integration Platform. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
